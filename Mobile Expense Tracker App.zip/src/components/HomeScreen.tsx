import React from 'react';
import { Search, MapPin, Star, TrendingUp, Sparkles, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import logoImage from 'figma:asset/fc368340dcc0f7e8cbb2d8bff15a22cb62ca8a2d.png';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const popularStyles = [
    { name: 'Braids', icon: '🎀', color: 'from-purple-400 to-purple-600' },
    { name: 'Twists', icon: '✨', color: 'from-pink-400 to-pink-600' },
    { name: 'Locs', icon: '🌟', color: 'from-orange-400 to-orange-600' },
    { name: 'Natural', icon: '🌺', color: 'from-green-400 to-green-600' }
  ];

  const featuredSalons = [
    {
      name: 'Bella Coiffure',
      location: 'Paris 18e',
      rating: 4.9,
      reviews: 234,
      image: 'https://images.unsplash.com/photo-1723541104653-5e478f84e687?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJvJTIwaGFpcnN0eWxlJTIwd29tYW4lMjBzYWxvbnxlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specialist: 'Box Braids'
    },
    {
      name: 'Afro Style Studio',
      location: 'Lyon 2e',
      rating: 4.8,
      reviews: 189,
      image: 'https://images.unsplash.com/photo-1702236240794-58dc4c6895e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwaGFpciUyMGJyYWlkc3xlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specialist: 'Twists'
    }
  ];

  return (
    <div className="bg-gradient-to-b from-purple-600 to-purple-800 min-h-full pb-20">
      {/* Header */}
      <div className="px-6 pt-16 pb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <img src={logoImage} alt="AfroPlan" className="w-10 h-10" />
            <div>
              <h1 className="text-2xl font-bold text-white">AfroPlan</h1>
              <p className="text-purple-200 text-sm">Trouvez votre style parfait</p>
            </div>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Search Bar */}
        <button 
          onClick={() => onNavigate('search')}
          className="w-full"
        >
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <div className="w-full pl-12 pr-4 py-4 rounded-2xl border-0 shadow-lg bg-white text-left text-gray-500">
              Rechercher un salon ou un style...
            </div>
          </div>
        </button>

        {/* Location Quick Select */}
        <div className="flex items-center gap-2 mt-4 text-white">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">Paris, France</span>
          <button className="text-xs underline ml-auto">Changer</button>
        </div>
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-t-[2rem] px-6 py-8 min-h-screen">
        {/* Popular Styles */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Styles Populaires</h2>
            <button 
              onClick={() => onNavigate('styles')}
              className="text-purple-600 text-sm font-medium flex items-center gap-1"
            >
              Voir tout
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {popularStyles.map((style, index) => (
              <button
                key={index}
                onClick={() => onNavigate('styles')}
                className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-gradient-to-br hover:scale-105 transition-transform"
                style={{
                  background: `linear-gradient(135deg, ${style.color.split(' ')[0].replace('from-', '')} 0%, ${style.color.split(' ')[1].replace('to-', '')} 100%)`
                }}
              >
                <span className="text-3xl">{style.icon}</span>
                <span className="text-xs font-medium text-white">{style.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Featured Salons */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Salons Recommandés</h2>
            <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
          </div>

          <div className="space-y-4">
            {featuredSalons.map((salon, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow"
              >
                <div className="relative h-48">
                  <ImageWithFallback
                    src={salon.image}
                    alt={salon.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="font-semibold text-sm">{salon.rating}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-1">{salon.name}</h3>
                  <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                    <MapPin className="w-4 h-4" />
                    <span>{salon.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">{salon.reviews} avis</span>
                    <span className="text-xs font-medium text-purple-600 bg-purple-50 px-3 py-1 rounded-full">
                      {salon.specialist}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom spacing for navigation */}
        <div className="h-8"></div>
      </div>
    </div>
  );
}
