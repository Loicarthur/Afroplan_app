import React, { useState } from 'react';
import { Search, SlidersHorizontal, Heart, Bookmark } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface StyleGalleryProps {
  onNavigate: (screen: string) => void;
}

export function StyleGallery({ onNavigate }: StyleGalleryProps) {
  const [selectedFilter, setSelectedFilter] = useState('Tous');

  const filters = ['Tous', 'Braids', 'Twists', 'Locs', 'Natural', 'Weave'];

  const styles = [
    {
      id: 1,
      name: 'Box Braids Longues',
      category: 'Braids',
      duration: '4-6h',
      price: '150-200€',
      image: 'https://images.unsplash.com/photo-1702236240794-58dc4c6895e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwaGFpciUyMGJyYWlkc3xlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      likes: 342
    },
    {
      id: 2,
      name: 'Natural Afro',
      category: 'Natural',
      duration: '2-3h',
      price: '80-120€',
      image: 'https://images.unsplash.com/photo-1763742936992-cac96be031b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwYWZybyUyMGhhaXJ8ZW58MXx8fHwxNzcwMDI2MjI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      likes: 289
    },
    {
      id: 3,
      name: 'Senegalese Twists',
      category: 'Twists',
      duration: '5-7h',
      price: '120-180€',
      image: 'https://images.unsplash.com/photo-1723541104653-5e478f84e687?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0d2lzdCUyMGhhaXJzdHlsZSUyMGFmcm98ZW58MXx8fHwxNzcwMDI2MjI4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      likes: 412
    },
    {
      id: 4,
      name: 'Cornrows Design',
      category: 'Braids',
      duration: '3-4h',
      price: '90-150€',
      image: 'https://images.unsplash.com/photo-1481385694031-f2b14f8621d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jucm93cyUyMGhhaXJzdHlsZXxlbnwxfHx8fDE3NzAwMjYyMzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      likes: 567
    },
    {
      id: 5,
      name: 'Goddess Locs',
      category: 'Locs',
      duration: '6-8h',
      price: '180-250€',
      image: 'https://images.unsplash.com/photo-1662991859083-86e0b45208b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcmVhZGxvY2tzJTIwaGFpciUyMHdvbWFufGVufDF8fHx8MTc3MDAyNjIzMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      likes: 198
    },
    {
      id: 6,
      name: 'Knotless Braids',
      category: 'Braids',
      duration: '5-6h',
      price: '160-220€',
      image: 'https://images.unsplash.com/photo-1733532915163-02915638c793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3glMjBicmFpZHMlMjBoYWlyc3R5bGV8ZW58MXx8fHwxNzY5OTgwMDA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      likes: 623
    }
  ];

  return (
    <div className="bg-gray-50 min-h-full">
      {/* Header */}
      <div className="bg-white px-6 pt-16 pb-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Galerie de Styles</h1>
        
        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher un style..."
            className="w-full pl-12 pr-12 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-300 outline-none"
          />
          <button className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-purple-600 rounded-lg">
            <SlidersHorizontal className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setSelectedFilter(filter)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                selectedFilter === filter
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="px-6 py-6">
        <div className="grid grid-cols-2 gap-4">
          {styles.map((style) => (
            <div
              key={style.id}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow"
            >
              <div className="relative aspect-[3/4]">
                <ImageWithFallback
                  src={style.image}
                  alt={style.name}
                  className="w-full h-full object-cover"
                />
                <button className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                  <Heart className="w-4 h-4 text-red-500" />
                </button>
                <button className="absolute top-3 left-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                  <Bookmark className="w-4 h-4 text-purple-600" />
                </button>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                  <span className="text-xs font-medium text-white bg-purple-500/80 px-2 py-1 rounded-full">
                    {style.category}
                  </span>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-semibold text-gray-800 text-sm mb-1">{style.name}</h3>
                <div className="flex items-center justify-between text-xs text-gray-600">
                  <span>{style.duration}</span>
                  <span className="font-medium text-purple-600">{style.price}</span>
                </div>
                <div className="flex items-center gap-1 mt-2">
                  <Heart className="w-3 h-3 text-red-500 fill-red-500" />
                  <span className="text-xs text-gray-500">{style.likes}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom spacing */}
        <div className="h-8"></div>
      </div>
    </div>
  );
}