import React from 'react';
import { User, MapPin, Calendar, Star, Settings, HelpCircle, LogOut, ChevronRight, Award, Bell } from 'lucide-react';
import logoImage from 'figma:asset/fc368340dcc0f7e8cbb2d8bff15a22cb62ca8a2d.png';

interface ProfileScreenProps {
  onNavigate: (screen: string) => void;
}

export function ProfileScreen({ onNavigate }: ProfileScreenProps) {
  const userStats = [
    { label: 'Réservations', value: '12', icon: Calendar },
    { label: 'Avis donnés', value: '8', icon: Star },
    { label: 'Salons suivis', value: '5', icon: Award }
  ];

  const menuItems = [
    { icon: User, label: 'Modifier le profil', action: () => {} },
    { icon: MapPin, label: 'Adresses sauvegardées', action: () => {} },
    { icon: Calendar, label: 'Mes réservations', action: () => {} },
    { icon: Bell, label: 'Notifications', action: () => {} },
    { icon: Settings, label: 'Paramètres', action: () => {} },
    { icon: HelpCircle, label: 'Aide & Support', action: () => {} }
  ];

  const recentBookings = [
    {
      salon: 'Bella Coiffure',
      service: 'Box Braids',
      date: '15 Jan 2026',
      status: 'Terminé',
      statusColor: 'bg-green-100 text-green-700'
    },
    {
      salon: 'Afro Style Studio',
      service: 'Twists',
      date: '22 Déc 2025',
      status: 'Terminé',
      statusColor: 'bg-green-100 text-green-700'
    }
  ];

  return (
    <div className="bg-gray-50 min-h-full pb-20">
      {/* Header with Profile */}
      <div className="bg-gradient-to-br from-purple-600 via-purple-700 to-pink-600 px-6 pt-16 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg">
            <img src={logoImage} alt="Profile" className="w-12 h-12" />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white mb-1">Marie Dupont</h1>
            <p className="text-purple-100 text-sm">marie.dupont@email.com</p>
            <div className="flex items-center gap-2 mt-2">
              <MapPin className="w-4 h-4 text-purple-200" />
              <span className="text-sm text-purple-100">Paris, France</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {userStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center"
              >
                <Icon className="w-5 h-5 text-white mx-auto mb-1" />
                <p className="text-2xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-xs text-purple-100">{stat.label}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Recent Bookings */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800">Réservations Récentes</h2>
            <button className="text-sm text-purple-600 font-medium flex items-center gap-1">
              Voir tout
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-3">
            {recentBookings.map((booking, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-800">{booking.salon}</h3>
                    <p className="text-sm text-gray-600">{booking.service}</p>
                  </div>
                  <span className={`text-xs font-medium px-3 py-1 rounded-full ${booking.statusColor}`}>
                    {booking.status}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Calendar className="w-4 h-4" />
                  <span>{booking.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Menu Items */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={index}
                onClick={item.action}
                className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0"
              >
                <div className="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-purple-600" />
                </div>
                <span className="flex-1 text-left font-medium text-gray-800">{item.label}</span>
                <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
              </button>
            );
          })}
        </div>

        {/* Logout Button */}
        <button className="w-full flex items-center justify-center gap-3 bg-white border border-red-200 text-red-600 py-4 rounded-xl font-semibold hover:bg-red-50 transition-colors shadow-sm">
          <LogOut className="w-5 h-5" />
          Se déconnecter
        </button>

        {/* App Version */}
        <div className="text-center">
          <p className="text-xs text-gray-400">Version 1.0.0</p>
          <p className="text-xs text-gray-400 mt-1">© 2026 AfroPlan. Tous droits réservés.</p>
        </div>
      </div>
    </div>
  );
}
