import React from 'react';
import { Heart, MapPin, Star, Trash2 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface FavoritesScreenProps {
  onNavigate: (screen: string) => void;
}

export function FavoritesScreen({ onNavigate }: FavoritesScreenProps) {
  const favoriteSalons = [
    {
      name: 'Bella Coiffure',
      location: 'Paris 18e',
      rating: 4.9,
      reviews: 234,
      image: 'https://images.unsplash.com/photo-1723541104653-5e478f84e687?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJvJTIwaGFpcnN0eWxlJTIwd29tYW4lMjBzYWxvbnxlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specialist: 'Box Braids'
    },
    {
      name: 'Afro Style Studio',
      location: 'Lyon 2e',
      rating: 4.8,
      reviews: 189,
      image: 'https://images.unsplash.com/photo-1702236240794-58dc4c6895e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwaGFpciUyMGJyYWlkc3xlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      specialist: 'Twists'
    }
  ];

  const favoriteStyles = [
    {
      name: 'Box Braids Longues',
      category: 'Braids',
      price: '150-200€',
      image: 'https://images.unsplash.com/photo-1702236240794-58dc4c6895e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwaGFpciUyMGJyYWlkc3xlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      name: 'Cornrows Design',
      category: 'Braids',
      price: '90-150€',
      image: 'https://images.unsplash.com/photo-1481385694031-f2b14f8621d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jucm93cyUyMGhhaXJzdHlsZXxlbnwxfHx8fDE3NzAwMjYyMzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      name: 'Natural Afro',
      category: 'Natural',
      price: '80-120€',
      image: 'https://images.unsplash.com/photo-1763742936992-cac96be031b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwYWZybyUyMGhhaXJ8ZW58MXx8fHwxNzcwMDI2MjI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      name: 'Knotless Braids',
      category: 'Braids',
      price: '160-220€',
      image: 'https://images.unsplash.com/photo-1733532915163-02915638c793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3glMjBicmFpZHMlMjBoYWlyc3R5bGV8ZW58MXx8fHwxNzY5OTgwMDA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ];

  return (
    <div className="bg-gray-50 min-h-full pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-6 pt-16 pb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Heart className="w-6 h-6 text-white fill-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Mes Favoris</h1>
            <p className="text-purple-100 text-sm">Vos salons et styles préférés</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Favorite Salons */}
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-4">Salons Favoris ({favoriteSalons.length})</h2>
          <div className="space-y-3">
            {favoriteSalons.map((salon, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl shadow-md overflow-hidden border border-gray-100"
              >
                <div className="flex gap-4 p-4">
                  <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                    <ImageWithFallback
                      src={salon.image}
                      alt={salon.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-800 mb-1">{salon.name}</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span className="text-sm font-medium">{salon.rating}</span>
                      </div>
                      <span className="text-xs text-gray-400">•</span>
                      <span className="text-xs text-gray-500">{salon.reviews} avis</span>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span>{salon.location}</span>
                    </div>
                  </div>
                  <button className="flex-shrink-0 p-2 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 className="w-5 h-5 text-red-500" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Favorite Styles */}
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-4">Styles Sauvegardés ({favoriteStyles.length})</h2>
          <div className="grid grid-cols-2 gap-3">
            {favoriteStyles.map((style, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl overflow-hidden shadow-md relative group"
              >
                <div className="relative aspect-[3/4]">
                  <ImageWithFallback
                    src={style.image}
                    alt={style.name}
                    className="w-full h-full object-cover"
                  />
                  <button className="absolute top-2 right-2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                    <span className="text-xs font-medium text-white bg-purple-500/80 px-2 py-1 rounded-full">
                      {style.category}
                    </span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-gray-800 text-sm mb-1">{style.name}</h3>
                  <span className="text-xs font-medium text-purple-600">{style.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Empty State (if no favorites) - hidden when there are favorites */}
        {favoriteSalons.length === 0 && favoriteStyles.length === 0 && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-12 h-12 text-gray-300" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Aucun favori</h3>
            <p className="text-gray-600 mb-6">
              Commencez à sauvegarder vos salons et styles préférés
            </p>
            <button
              onClick={() => onNavigate('home')}
              className="px-6 py-3 bg-purple-600 text-white rounded-xl font-medium"
            >
              Explorer les salons
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
