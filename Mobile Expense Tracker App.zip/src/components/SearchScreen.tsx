import React, { useState } from 'react';
import { Search, MapPin, DollarSign, Clock, Star, SlidersHorizontal, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface SearchScreenProps {
  onNavigate: (screen: string) => void;
}

export function SearchScreen({ onNavigate }: SearchScreenProps) {
  const [showFilters, setShowFilters] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState('');
  const [priceRange, setPriceRange] = useState([0, 300]);
  const [selectedDistrict, setSelectedDistrict] = useState('');

  const searchResults = [
    {
      name: 'Bella Coiffure',
      location: 'Paris 18e',
      rating: 4.9,
      reviews: 234,
      distance: '1.2 km',
      priceRange: '€€€',
      image: 'https://images.unsplash.com/photo-1723541104653-5e478f84e687?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJvJTIwaGFpcnN0eWxlJTIwd29tYW4lMjBzYWxvbnxlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      available: 'Aujourd\'hui 15h'
    },
    {
      name: 'Afro Style Studio',
      location: 'Paris 11e',
      rating: 4.8,
      reviews: 189,
      distance: '2.5 km',
      priceRange: '€€',
      image: 'https://images.unsplash.com/photo-1702236240794-58dc4c6895e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwaGFpciUyMGJyYWlkc3xlbnwxfHx8fDE3NzAwMjYyMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      available: 'Demain 10h'
    },
    {
      name: 'Natural Beauty Salon',
      location: 'Paris 13e',
      rating: 4.7,
      reviews: 156,
      distance: '3.8 km',
      priceRange: '€€€',
      image: 'https://images.unsplash.com/photo-1763742936992-cac96be031b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwYWZybyUyMGhhaXJ8ZW58MXx8fHwxNzcwMDI2MjI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      available: 'Mercredi 14h'
    }
  ];

  const styleOptions = ['Box Braids', 'Twists', 'Cornrows', 'Natural', 'Locs', 'Weave'];
  const districts = ['1er', '2e', '10e', '11e', '13e', '18e', '19e', '20e'];

  return (
    <div className="bg-gray-50 min-h-full">
      {/* Header */}
      <div className="bg-white px-6 pt-16 pb-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Recherche</h1>
        
        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Salon, style, quartier..."
            className="w-full pl-12 pr-12 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-300 outline-none"
          />
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Quick Filters */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          <button className="px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium whitespace-nowrap flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Proche de moi
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full text-sm font-medium whitespace-nowrap flex items-center gap-2">
            <Star className="w-4 h-4" />
            Mieux notés
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full text-sm font-medium whitespace-nowrap flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Disponible
          </button>
        </div>
      </div>

      {/* Advanced Filters Panel */}
      {showFilters && (
        <div className="bg-white border-b border-gray-200 px-6 py-6 space-y-4 animate-in slide-in-from-top">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-gray-800">Filtres Avancés</h3>
            <button onClick={() => setShowFilters(false)}>
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Style Selection */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Type de coiffure</label>
            <div className="flex flex-wrap gap-2">
              {styleOptions.map((style) => (
                <button
                  key={style}
                  onClick={() => setSelectedStyle(style)}
                  className={`px-3 py-1.5 rounded-lg text-sm ${
                    selectedStyle === style
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">
              Budget: {priceRange[0]}€ - {priceRange[1]}€
            </label>
            <input
              type="range"
              min="0"
              max="300"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
              className="w-full"
            />
          </div>

          {/* District */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Arrondissement</label>
            <div className="flex flex-wrap gap-2">
              {districts.map((district) => (
                <button
                  key={district}
                  onClick={() => setSelectedDistrict(district)}
                  className={`px-3 py-1.5 rounded-lg text-sm ${
                    selectedDistrict === district
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {district}
                </button>
              ))}
            </div>
          </div>

          <button className="w-full bg-purple-600 text-white py-3 rounded-xl font-medium">
            Appliquer les filtres
          </button>
        </div>
      )}

      {/* Results */}
      <div className="px-6 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-gray-800">
            {searchResults.length} salons trouvés
          </h2>
          <button className="text-sm text-purple-600 font-medium">Trier par</button>
        </div>

        <div className="space-y-4">
          {searchResults.map((salon, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-gray-100"
            >
              <div className="flex gap-4 p-4">
                <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={salon.image}
                    alt={salon.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-800 mb-1">{salon.name}</h3>
                  
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-sm font-medium">{salon.rating}</span>
                      <span className="text-xs text-gray-500">({salon.reviews})</span>
                    </div>
                    <span className="text-xs text-gray-400">•</span>
                    <span className="text-sm text-gray-600">{salon.priceRange}</span>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{salon.location}</span>
                    </div>
                    <span className="text-xs">{salon.distance}</span>
                  </div>

                  <div className="mt-2 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-green-600 font-medium">{salon.available}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom spacing */}
        <div className="h-8"></div>
      </div>
    </div>
  );
}