import React, { useState } from 'react';
import { Home, Search, Heart, User, Grid } from 'lucide-react';
import { HomeScreen } from './components/HomeScreen';
import { StyleGallery } from './components/StyleGallery';
import { SearchScreen } from './components/SearchScreen';
import { FavoritesScreen } from './components/FavoritesScreen';
import { ProfileScreen } from './components/ProfileScreen';
import logoImage from 'figma:asset/fc368340dcc0f7e8cbb2d8bff15a22cb62ca8a2d.png';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('home');

  const screens = {
    home: <HomeScreen onNavigate={setCurrentScreen} />,
    styles: <StyleGallery onNavigate={setCurrentScreen} />,
    search: <SearchScreen onNavigate={setCurrentScreen} />,
    favorites: <FavoritesScreen onNavigate={setCurrentScreen} />,
    profile: <ProfileScreen onNavigate={setCurrentScreen} />
  };

  const navItems = [
    { id: 'home', icon: Home, label: 'Accueil' },
    { id: 'styles', icon: Grid, label: 'Styles' },
    { id: 'search', icon: Search, label: 'Recherche' },
    { id: 'favorites', icon: Heart, label: 'Favoris' },
    { id: 'profile', icon: User, label: 'Profil' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 flex items-center justify-center p-8">
      <div className="relative">
        {/* iPhone Frame */}
        <div className="bg-black rounded-[3rem] p-3 shadow-2xl">
          <div className="bg-white rounded-[2.5rem] overflow-hidden relative" style={{ width: '393px', height: '852px' }}>
            {/* Dynamic Island */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-8 bg-black rounded-b-3xl z-50"></div>
            
            {/* Screen Content */}
            <div className="h-full flex flex-col">
              {/* Main Content Area */}
              <div className="flex-1 overflow-y-auto">
                {screens[currentScreen]}
              </div>

              {/* Bottom Navigation */}
              <div className="bg-white border-t border-gray-200 px-2 pb-6 pt-2 shadow-lg">
                <div className="flex items-center justify-around">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentScreen === item.id;
                    
                    return (
                      <button
                        key={item.id}
                        onClick={() => setCurrentScreen(item.id)}
                        className={`flex flex-col items-center gap-1 py-2 px-3 rounded-xl transition-all ${
                          isActive
                            ? 'text-purple-600'
                            : 'text-gray-400 hover:text-gray-600'
                        }`}
                      >
                        <Icon className={`w-6 h-6 ${isActive ? 'fill-purple-100' : ''}`} />
                        <span className="text-[10px] font-medium">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* App Info */}
        <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-white px-6 py-3 rounded-full shadow-lg">
          <img src={logoImage} alt="AfroPlan Logo" className="w-8 h-8" />
          <span className="font-bold text-gray-800">AfroPlan</span>
        </div>
      </div>
    </div>
  );
}
